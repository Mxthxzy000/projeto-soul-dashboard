"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Truck, Plus, MapPin, Clock, CheckCircle, AlertCircle } from "lucide-react"

const shipments = [
  {
    id: "TN-003",
    date: "22/04/2024",
    carrier: "Transportadora Rápido",
    origin: "Centro de Distribuição SP",
    destination: "Loja Santo André",
    status: "Em trânsito",
    statusColor: "bg-[#e67e22]",
    eta: "24/04/2024",
  },
  {
    id: "TN-022",
    date: "20/04/2024",
    carrier: "Transportadora Velox",
    origin: "Fábrica Campinas",
    destination: "Distribuidora Mena",
    status: "Em trânsito",
    statusColor: "bg-[#e67e22]",
    eta: "23/04/2024",
  },
  {
    id: "TN-001",
    date: "16/04/2024",
    carrier: "Transportadora Expressa",
    origin: "Centro de Distribuição SP",
    destination: "Eltai Ribeirão",
    status: "Entregue",
    statusColor: "bg-[#10b981]",
    eta: "18/04/2024",
  },
  {
    id: "TN-000",
    date: "15/04/2024",
    carrier: "Transportadora Sul",
    origin: "Fábrica Campinas",
    destination: "Loja Centro",
    status: "Entregue",
    statusColor: "bg-[#10b981]",
    eta: "17/04/2024",
  },
  {
    id: "TN-005",
    date: "23/04/2024",
    carrier: "Transportadora Norte",
    origin: "Centro de Distribuição SP",
    destination: "Loja Osasco",
    status: "Aguardando",
    statusColor: "bg-[#3b82f6]",
    eta: "25/04/2024",
  },
]

const stats = [
  { label: "Em Trânsito", value: "12", icon: Truck, color: "text-[#e67e22]", bg: "bg-[#e67e22]/10" },
  { label: "Entregues Hoje", value: "8", icon: CheckCircle, color: "text-[#10b981]", bg: "bg-[#10b981]/10" },
  { label: "Aguardando", value: "5", icon: Clock, color: "text-[#3b82f6]", bg: "bg-[#3b82f6]/10" },
  { label: "Atrasados", value: "2", icon: AlertCircle, color: "text-[#ef4444]", bg: "bg-[#ef4444]/10" },
]

export default function TransportePage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Transporte</h1>
            <p className="text-sm text-gray-500">Gerencie suas entregas e transportes</p>
          </div>
          <button className="flex items-center gap-2 rounded-lg bg-[#e67e22] px-4 py-2.5 text-sm font-medium text-white transition-all duration-200 hover:bg-[#d35400] hover:shadow-lg hover:shadow-[#e67e22]/30">
            <Plus className="h-4 w-4" />
            Nova Entrega
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className={`w-fit rounded-lg ${stat.bg} p-2.5`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <p className="mt-3 text-sm text-gray-500">{stat.label}</p>
              <p className="mt-1 text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Shipments Table */}
        <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Todas as Entregas</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="pb-3 text-left font-medium text-gray-500">ID</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Data</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Transportadora</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Origem</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Destino</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Previsão</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Status</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Ações</th>
                </tr>
              </thead>
              <tbody>
                {shipments.map((shipment) => (
                  <tr
                    key={shipment.id}
                    className="group border-b border-gray-100 transition-colors hover:bg-gray-50"
                  >
                    <td className="py-3 font-medium text-gray-900">{shipment.id}</td>
                    <td className="py-3 text-gray-500">{shipment.date}</td>
                    <td className="py-3 text-gray-700">{shipment.carrier}</td>
                    <td className="py-3">
                      <div className="flex items-center gap-1 text-gray-700">
                        <MapPin className="h-3 w-3 text-gray-400" />
                        {shipment.origin}
                      </div>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-1 text-gray-700">
                        <MapPin className="h-3 w-3 text-[#e67e22]" />
                        {shipment.destination}
                      </div>
                    </td>
                    <td className="py-3 text-gray-500">{shipment.eta}</td>
                    <td className="py-3">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium text-white ${shipment.statusColor}`}
                      >
                        {shipment.status}
                      </span>
                    </td>
                    <td className="py-3">
                      <button className="rounded-lg border border-gray-200 px-3 py-1.5 text-xs text-gray-600 transition-all duration-200 hover:border-[#e67e22] hover:text-[#e67e22]">
                        Detalhes
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
