"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { TrendingUp, TrendingDown, DollarSign, CreditCard, ArrowUpRight, ArrowDownRight } from "lucide-react"
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const monthlyData = [
  { name: "Jan", receita: 320000, despesa: 180000 },
  { name: "Fev", receita: 380000, despesa: 190000 },
  { name: "Mar", receita: 350000, despesa: 175000 },
  { name: "Abr", receita: 458750, despesa: 189320 },
]

const expenseCategories = [
  { name: "Salários", value: 85000, color: "#e67e22" },
  { name: "Fornecedores", value: 45000, color: "#10b981" },
  { name: "Logística", value: 32000, color: "#3b82f6" },
  { name: "Marketing", value: 15000, color: "#8b5cf6" },
  { name: "Outros", value: 12320, color: "#f59e0b" },
]

const transactions = [
  { id: 1, desc: "Venda - Loja Centro", value: 12500, type: "income", date: "22/04/2024" },
  { id: 2, desc: "Pagamento Fornecedor", value: 8200, type: "expense", date: "22/04/2024" },
  { id: 3, desc: "Venda - E-commerce", value: 4800, type: "income", date: "21/04/2024" },
  { id: 4, desc: "Frete - Transportadora", value: 1500, type: "expense", date: "21/04/2024" },
  { id: 5, desc: "Venda - Distribuidora", value: 28000, type: "income", date: "20/04/2024" },
]

export default function FinanceiroPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Financeiro</h1>
          <p className="text-sm text-gray-500">Acompanhe suas receitas e despesas</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <div className="flex items-center justify-between">
              <div className="rounded-lg bg-[#10b981]/10 p-2.5">
                <TrendingUp className="h-5 w-5 text-[#10b981]" />
              </div>
              <span className="flex items-center gap-1 text-xs text-[#10b981]">
                <ArrowUpRight className="h-3 w-3" />
                +12.5%
              </span>
            </div>
            <p className="mt-3 text-sm text-gray-500">Receita Total (Mês)</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">R$ 458.750,00</p>
          </div>

          <div className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <div className="flex items-center justify-between">
              <div className="rounded-lg bg-[#ef4444]/10 p-2.5">
                <TrendingDown className="h-5 w-5 text-[#ef4444]" />
              </div>
              <span className="flex items-center gap-1 text-xs text-[#ef4444]">
                <ArrowDownRight className="h-3 w-3" />
                +3.2%
              </span>
            </div>
            <p className="mt-3 text-sm text-gray-500">Despesas (Mês)</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">R$ 189.320,00</p>
          </div>

          <div className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <div className="flex items-center justify-between">
              <div className="rounded-lg bg-[#e67e22]/10 p-2.5">
                <DollarSign className="h-5 w-5 text-[#e67e22]" />
              </div>
            </div>
            <p className="mt-3 text-sm text-gray-500">Lucro Líquido</p>
            <p className="mt-1 text-2xl font-bold text-[#10b981]">R$ 269.430,00</p>
          </div>

          <div className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <div className="flex items-center justify-between">
              <div className="rounded-lg bg-[#3b82f6]/10 p-2.5">
                <CreditCard className="h-5 w-5 text-[#3b82f6]" />
              </div>
            </div>
            <p className="mt-3 text-sm text-gray-500">A Receber</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">R$ 85.200,00</p>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Revenue vs Expenses */}
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Receitas vs Despesas</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}K`} />
                  <Tooltip
                    formatter={(value: number) => `R$ ${value.toLocaleString()}`}
                    contentStyle={{ borderRadius: "8px", border: "1px solid #e5e7eb" }}
                  />
                  <Bar dataKey="receita" fill="#10b981" radius={[4, 4, 0, 0]} name="Receita" />
                  <Bar dataKey="despesa" fill="#ef4444" radius={[4, 4, 0, 0]} name="Despesa" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Expense Distribution */}
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Distribuição de Despesas</h2>
            <div className="flex items-center gap-4">
              <div className="h-48 w-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={expenseCategories}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      dataKey="value"
                    >
                      {expenseCategories.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => `R$ ${value.toLocaleString()}`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-2">
                {expenseCategories.map((cat) => (
                  <div key={cat.name} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full" style={{ backgroundColor: cat.color }}></span>
                      <span className="text-gray-600">{cat.name}</span>
                    </div>
                    <span className="font-medium text-gray-900">R$ {cat.value.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Transações Recentes</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="pb-3 text-left font-medium text-gray-500">Descrição</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Data</th>
                  <th className="pb-3 text-right font-medium text-gray-500">Valor</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-gray-100 transition-colors hover:bg-gray-50">
                    <td className="py-3 font-medium text-gray-900">{tx.desc}</td>
                    <td className="py-3 text-gray-500">{tx.date}</td>
                    <td className={`py-3 text-right font-medium ${tx.type === "income" ? "text-[#10b981]" : "text-[#ef4444]"}`}>
                      {tx.type === "income" ? "+" : "-"} R$ {tx.value.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
