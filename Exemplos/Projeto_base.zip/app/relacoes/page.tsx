"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Users, Plus, Search, Mail, Phone, Building, UserCheck, UserX } from "lucide-react"
import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const employees = [
  { id: 1, name: "Ana Silva", email: "ana.silva@empresa.com", phone: "(11) 99999-1111", department: "Vendas", role: "Gerente", status: "active" },
  { id: 2, name: "Carlos Santos", email: "carlos.santos@empresa.com", phone: "(11) 99999-2222", department: "TI", role: "Desenvolvedor", status: "active" },
  { id: 3, name: "Maria Oliveira", email: "maria.oliveira@empresa.com", phone: "(11) 99999-3333", department: "RH", role: "Analista", status: "active" },
  { id: 4, name: "João Pereira", email: "joao.pereira@empresa.com", phone: "(11) 99999-4444", department: "Logística", role: "Coordenador", status: "active" },
  { id: 5, name: "Fernanda Costa", email: "fernanda.costa@empresa.com", phone: "(11) 99999-5555", department: "Financeiro", role: "Analista", status: "inactive" },
  { id: 6, name: "Pedro Lima", email: "pedro.lima@empresa.com", phone: "(11) 99999-6666", department: "Vendas", role: "Vendedor", status: "active" },
  { id: 7, name: "Juliana Martins", email: "juliana.martins@empresa.com", phone: "(11) 99999-7777", department: "Marketing", role: "Designer", status: "active" },
  { id: 8, name: "Ricardo Alves", email: "ricardo.alves@empresa.com", phone: "(11) 99999-8888", department: "Produção", role: "Supervisor", status: "active" },
]

const stats = [
  { label: "Total de Funcionários", value: "142", icon: Users, color: "text-[#3b82f6]", bg: "bg-[#3b82f6]/10" },
  { label: "Ativos", value: "138", icon: UserCheck, color: "text-[#10b981]", bg: "bg-[#10b981]/10" },
  { label: "Inativos", value: "4", icon: UserX, color: "text-[#ef4444]", bg: "bg-[#ef4444]/10" },
  { label: "Departamentos", value: "8", icon: Building, color: "text-[#e67e22]", bg: "bg-[#e67e22]/10" },
]

const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)
}

const getAvatarColor = (name: string) => {
  const colors = ["bg-[#e67e22]", "bg-[#10b981]", "bg-[#3b82f6]", "bg-[#8b5cf6]", "bg-[#ef4444]"]
  const index = name.charCodeAt(0) % colors.length
  return colors[index]
}

export default function RelacoesPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredEmployees = employees.filter(
    (e) =>
      e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.department.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Relações</h1>
            <p className="text-sm text-gray-500">Gerencie funcionários e colaboradores</p>
          </div>
          <button className="flex items-center gap-2 rounded-lg bg-[#e67e22] px-4 py-2.5 text-sm font-medium text-white transition-all duration-200 hover:bg-[#d35400] hover:shadow-lg hover:shadow-[#e67e22]/30">
            <Plus className="h-4 w-4" />
            Novo Funcionário
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className={`w-fit rounded-lg ${stat.bg} p-2.5`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <p className="mt-3 text-sm text-gray-500">{stat.label}</p>
              <p className="mt-1 text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Search and Filter */}
        <div className="rounded-xl bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Lista de Funcionários</h2>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar funcionário..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full rounded-lg border border-gray-200 py-2 pl-10 pr-4 text-sm focus:border-[#e67e22] focus:outline-none focus:ring-1 focus:ring-[#e67e22]"
              />
            </div>
          </div>
        </div>

        {/* Employee Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredEmployees.map((employee) => (
            <div
              key={employee.id}
              className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="flex items-start gap-3">
                <Avatar className={`h-12 w-12 ${getAvatarColor(employee.name)}`}>
                  <AvatarFallback className="text-white">{getInitials(employee.name)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-gray-900">{employee.name}</h3>
                    <span
                      className={`h-2 w-2 rounded-full ${
                        employee.status === "active" ? "bg-[#10b981]" : "bg-[#ef4444]"
                      }`}
                    ></span>
                  </div>
                  <p className="text-sm text-[#e67e22]">{employee.role}</p>
                </div>
              </div>

              <div className="mt-4 space-y-2 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Building className="h-4 w-4 text-gray-400" />
                  {employee.department}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <span className="truncate">{employee.email}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Phone className="h-4 w-4 text-gray-400" />
                  {employee.phone}
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button className="flex-1 rounded-lg border border-gray-200 py-2 text-sm font-medium text-gray-600 transition-all duration-200 hover:border-[#e67e22] hover:text-[#e67e22]">
                  Ver Perfil
                </button>
                <button className="flex-1 rounded-lg bg-[#e67e22]/10 py-2 text-sm font-medium text-[#e67e22] transition-all duration-200 hover:bg-[#e67e22] hover:text-white">
                  Editar
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  )
}
