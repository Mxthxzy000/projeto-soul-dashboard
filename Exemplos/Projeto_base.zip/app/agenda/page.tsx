"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Calendar, Plus, Clock } from "lucide-react"
import { useState } from "react"

const events = [
  {
    id: 1,
    time: "08:00",
    title: "Abertura do Expediente",
    date: "Segunda-feira, 22 abril",
    type: "daily",
  },
  {
    id: 2,
    time: "10:00",
    title: "Reunião com equipe de produção",
    date: "Terça-feira, 24 abril",
    type: "meeting",
  },
  {
    id: 3,
    time: "13:00",
    title: "Auditoria da contabilidade",
    date: "Terça-feira, 24 abril",
    type: "audit",
  },
  {
    id: 4,
    time: "09:00",
    title: "Treinamento de segurança",
    date: "Quarta-feira, 25 abril",
    type: "training",
  },
  {
    id: 5,
    time: "14:00",
    title: "Revisão de metas trimestrais",
    date: "Quinta-feira, 26 abril",
    type: "meeting",
  },
  {
    id: 6,
    time: "11:00",
    title: "Entrevista com candidatos",
    date: "Sexta-feira, 27 abril",
    type: "interview",
  },
]

export default function AgendaPage() {
  const [selectedDate, setSelectedDate] = useState<string | null>(null)

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Agenda</h1>
            <p className="text-sm text-gray-500">Gerencie seus eventos e compromissos</p>
          </div>
          <button className="flex items-center gap-2 rounded-lg bg-[#e67e22] px-4 py-2.5 text-sm font-medium text-white transition-all duration-200 hover:bg-[#d35400] hover:shadow-lg hover:shadow-[#e67e22]/30">
            <Plus className="h-4 w-4" />
            Novo Evento
          </button>
        </div>

        {/* Calendar Preview */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Mini Calendar */}
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
            <div className="mb-4 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-[#e67e22]" />
              <h2 className="text-lg font-semibold text-gray-900">Abril 2024</h2>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-sm">
              {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
                <div key={day} className="py-2 font-medium text-gray-500">
                  {day}
                </div>
              ))}
              {Array.from({ length: 30 }, (_, i) => i + 1).map((day) => (
                <button
                  key={day}
                  onClick={() => setSelectedDate(`${day}/04/2024`)}
                  className={`rounded-lg py-2 text-sm transition-all duration-200 ${
                    [22, 24, 25, 26, 27].includes(day)
                      ? "bg-[#e67e22] font-medium text-white"
                      : "text-gray-700 hover:bg-orange-50"
                  }`}
                >
                  {day}
                </button>
              ))}
            </div>
          </div>

          {/* Events List */}
          <div className="lg:col-span-2 rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Próximos Eventos</h2>
            <div className="space-y-3">
              {events.map((event) => (
                <div
                  key={event.id}
                  className="group flex items-start gap-4 rounded-lg border border-gray-100 p-4 transition-all duration-200 hover:border-[#e67e22]/30 hover:bg-orange-50/50 hover:shadow-md"
                >
                  <div className="flex flex-col items-center rounded-lg bg-[#e67e22]/10 px-3 py-2">
                    <Clock className="h-4 w-4 text-[#e67e22]" />
                    <span className="mt-1 text-sm font-bold text-[#e67e22]">{event.time}</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 transition-colors group-hover:text-[#e67e22]">
                      {event.title}
                    </p>
                    <p className="mt-0.5 text-sm text-gray-500">{event.date}</p>
                  </div>
                  <button className="rounded-lg border border-gray-200 px-3 py-1.5 text-sm text-gray-600 opacity-0 transition-all duration-200 hover:border-[#e67e22] hover:text-[#e67e22] group-hover:opacity-100">
                    Editar
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
