"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { FileText, Download, Filter, TrendingUp, TrendingDown } from "lucide-react"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"

const salesData = [
  { name: "Jan", vendas: 12000, meta: 15000 },
  { name: "Fev", vendas: 19000, meta: 15000 },
  { name: "Mar", vendas: 15000, meta: 18000 },
  { name: "Abr", vendas: 28000, meta: 20000 },
  { name: "Mai", vendas: 22000, meta: 22000 },
  { name: "Jun", vendas: 25000, meta: 25000 },
  { name: "Jul", vendas: 32000, meta: 28000 },
  { name: "Ago", vendas: 38000, meta: 30000 },
]

const categoryData = [
  { name: "Eletrônicos", value: 45000 },
  { name: "Vestuário", value: 32000 },
  { name: "Alimentos", value: 28000 },
  { name: "Móveis", value: 18000 },
  { name: "Outros", value: 12000 },
]

const reports = [
  { name: "Relatório de Vendas - Abril 2024", date: "22/04/2024", type: "Vendas" },
  { name: "Relatório Financeiro Q1 2024", date: "15/04/2024", type: "Financeiro" },
  { name: "Análise de Estoque", date: "10/04/2024", type: "Estoque" },
  { name: "Performance de Funcionários", date: "05/04/2024", type: "RH" },
  { name: "Relatório de Logística", date: "01/04/2024", type: "Transporte" },
]

export default function RelatorioPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Relatórios</h1>
            <p className="text-sm text-gray-500">Visualize análises e métricas do negócio</p>
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-all duration-200 hover:border-[#e67e22] hover:text-[#e67e22]">
              <Filter className="h-4 w-4" />
              Filtrar
            </button>
            <button className="flex items-center gap-2 rounded-lg bg-[#e67e22] px-4 py-2.5 text-sm font-medium text-white transition-all duration-200 hover:bg-[#d35400] hover:shadow-lg hover:shadow-[#e67e22]/30">
              <Download className="h-4 w-4" />
              Exportar
            </button>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <p className="text-sm text-gray-500">Vendas Totais</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">R$ 191.000</p>
            <div className="mt-2 flex items-center gap-1 text-xs text-[#10b981]">
              <TrendingUp className="h-3 w-3" />
              <span>+18.5% vs período anterior</span>
            </div>
          </div>
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <p className="text-sm text-gray-500">Ticket Médio</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">R$ 182,35</p>
            <div className="mt-2 flex items-center gap-1 text-xs text-[#10b981]">
              <TrendingUp className="h-3 w-3" />
              <span>+5.2% vs período anterior</span>
            </div>
          </div>
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <p className="text-sm text-gray-500">Total de Pedidos</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">1,045</p>
            <div className="mt-2 flex items-center gap-1 text-xs text-[#10b981]">
              <TrendingUp className="h-3 w-3" />
              <span>+12.8% vs período anterior</span>
            </div>
          </div>
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
            <p className="text-sm text-gray-500">Taxa de Conversão</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">3.8%</p>
            <div className="mt-2 flex items-center gap-1 text-xs text-[#ef4444]">
              <TrendingDown className="h-3 w-3" />
              <span>-0.5% vs período anterior</span>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Sales vs Target */}
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Vendas vs Meta</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={salesData}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}K`} />
                  <Tooltip
                    formatter={(value: number) => `R$ ${value.toLocaleString()}`}
                    contentStyle={{ borderRadius: "8px", border: "1px solid #e5e7eb" }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="vendas" stroke="#e67e22" strokeWidth={2} dot={{ r: 4 }} name="Vendas" />
                  <Line type="monotone" dataKey="meta" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" dot={false} name="Meta" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Sales by Category */}
          <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Vendas por Categoria</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData} layout="vertical">
                  <XAxis type="number" axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}K`} />
                  <YAxis type="category" dataKey="name" axisLine={false} tickLine={false} width={80} />
                  <Tooltip
                    formatter={(value: number) => `R$ ${value.toLocaleString()}`}
                    contentStyle={{ borderRadius: "8px", border: "1px solid #e5e7eb" }}
                  />
                  <Bar dataKey="value" fill="#e67e22" radius={[0, 4, 4, 0]} name="Vendas" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recent Reports */}
        <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Relatórios Gerados</h2>
          <div className="space-y-3">
            {reports.map((report, index) => (
              <div
                key={index}
                className="group flex items-center justify-between rounded-lg border border-gray-100 p-4 transition-all duration-200 hover:border-[#e67e22]/30 hover:bg-orange-50/50"
              >
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-[#e67e22]/10 p-2">
                    <FileText className="h-5 w-5 text-[#e67e22]" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{report.name}</p>
                    <p className="text-sm text-gray-500">{report.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-600">
                    {report.type}
                  </span>
                  <button className="rounded-lg border border-gray-200 p-2 text-gray-600 opacity-0 transition-all duration-200 hover:border-[#e67e22] hover:text-[#e67e22] group-hover:opacity-100">
                    <Download className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
