"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Package, Plus, Search, AlertTriangle, CheckCircle, XCircle, Edit, Trash2 } from "lucide-react"
import { useState } from "react"

const products = [
  { id: 1, name: "Notebook Dell Inspiron 15", sku: "NB-001", category: "Eletrônicos", stock: 45, minStock: 10, price: 3599.00, status: "ok" },
  { id: 2, name: "Mouse Logitech MX Master", sku: "MS-002", category: "Periféricos", stock: 120, minStock: 30, price: 499.00, status: "ok" },
  { id: 3, name: "Teclado Mecânico Redragon", sku: "TC-003", category: "Periféricos", stock: 8, minStock: 20, price: 289.00, status: "low" },
  { id: 4, name: "Monitor LG 27\" 4K", sku: "MN-004", category: "Monitores", stock: 0, minStock: 5, price: 2199.00, status: "out" },
  { id: 5, name: "Headset HyperX Cloud", sku: "HS-005", category: "Áudio", stock: 32, minStock: 15, price: 399.00, status: "ok" },
  { id: 6, name: "Webcam Logitech C920", sku: "WC-006", category: "Periféricos", stock: 5, minStock: 10, price: 449.00, status: "low" },
  { id: 7, name: "SSD Samsung 1TB", sku: "SD-007", category: "Armazenamento", stock: 78, minStock: 25, price: 599.00, status: "ok" },
  { id: 8, name: "Memória RAM 16GB DDR4", sku: "MM-008", category: "Componentes", stock: 0, minStock: 20, price: 299.00, status: "out" },
]

const stats = [
  { label: "Total de Produtos", value: "1,245", icon: Package, color: "text-[#3b82f6]", bg: "bg-[#3b82f6]/10" },
  { label: "Em Estoque", value: "1,172", icon: CheckCircle, color: "text-[#10b981]", bg: "bg-[#10b981]/10" },
  { label: "Estoque Baixo", value: "45", icon: AlertTriangle, color: "text-[#e67e22]", bg: "bg-[#e67e22]/10" },
  { label: "Esgotados", value: "28", icon: XCircle, color: "text-[#ef4444]", bg: "bg-[#ef4444]/10" },
]

export default function EstoquePage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ok":
        return <span className="inline-flex rounded-full bg-[#10b981] px-2.5 py-1 text-xs font-medium text-white">Em estoque</span>
      case "low":
        return <span className="inline-flex rounded-full bg-[#e67e22] px-2.5 py-1 text-xs font-medium text-white">Estoque baixo</span>
      case "out":
        return <span className="inline-flex rounded-full bg-[#ef4444] px-2.5 py-1 text-xs font-medium text-white">Esgotado</span>
      default:
        return null
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Estoque</h1>
            <p className="text-sm text-gray-500">Gerencie seus produtos e inventário</p>
          </div>
          <button className="flex items-center gap-2 rounded-lg bg-[#e67e22] px-4 py-2.5 text-sm font-medium text-white transition-all duration-200 hover:bg-[#d35400] hover:shadow-lg hover:shadow-[#e67e22]/30">
            <Plus className="h-4 w-4" />
            Novo Produto
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="group rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className={`w-fit rounded-lg ${stat.bg} p-2.5`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <p className="mt-3 text-sm text-gray-500">{stat.label}</p>
              <p className="mt-1 text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Products Table */}
        <div className="rounded-xl bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-lg">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Lista de Produtos</h2>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar produto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full rounded-lg border border-gray-200 py-2 pl-10 pr-4 text-sm focus:border-[#e67e22] focus:outline-none focus:ring-1 focus:ring-[#e67e22]"
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="pb-3 text-left font-medium text-gray-500">Produto</th>
                  <th className="pb-3 text-left font-medium text-gray-500">SKU</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Categoria</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Estoque</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Preço</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Status</th>
                  <th className="pb-3 text-left font-medium text-gray-500">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product) => (
                  <tr
                    key={product.id}
                    className="group border-b border-gray-100 transition-colors hover:bg-gray-50"
                  >
                    <td className="py-3 font-medium text-gray-900">{product.name}</td>
                    <td className="py-3 text-gray-500">{product.sku}</td>
                    <td className="py-3 text-gray-700">{product.category}</td>
                    <td className="py-3">
                      <span className={`font-medium ${product.stock <= product.minStock ? "text-[#ef4444]" : "text-gray-900"}`}>
                        {product.stock}
                      </span>
                      <span className="text-gray-400"> / {product.minStock} min</span>
                    </td>
                    <td className="py-3 font-medium text-gray-900">
                      R$ {product.price.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3">{getStatusBadge(product.status)}</td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        <button className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-[#e67e22]/10 hover:text-[#e67e22]">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-[#ef4444]/10 hover:text-[#ef4444]">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
